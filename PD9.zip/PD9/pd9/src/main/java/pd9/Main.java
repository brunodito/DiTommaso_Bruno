package pd9;

public class Main {
    public static void main(String[] args) {
        Expresion expresion = new Expresion();
        String lista = "{{{}}}";
        System.out.println(expresion.controlCorchetes(lista));
    }
}