package pd9;
import java.util.Stack;

public class Expresion {
    public boolean controlCorchetes (String lista)
    {
        Stack <Character> pilaDeCorchetes = new Stack<>();
        for (int i = 0; i < lista.length(); i++)
        {
            Character caracter = lista.charAt(i);
            if (caracter == '{')
            {
                pilaDeCorchetes.push(caracter);
            } else if (caracter == '}') {
                if (pilaDeCorchetes.isEmpty())
                {
                    return false;
                }
                Character ultimoCaracter = pilaDeCorchetes.pop();
                if (ultimoCaracter != '{')
                {
                    return false;
                }
            }
        }
        if (pilaDeCorchetes.isEmpty())
        {
            return true;
        } else {
            return false;
        }
    }
}
