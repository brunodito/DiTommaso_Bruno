package tablero;

public class Tablero {
    public static void imprimirTablero(int largo, int ancho){
        String caracter = "# ";
        int i = 1;
        while (i <= ancho){
            System.out.println(caracter.repeat(largo));
            i++;
        }
    }
    public static void main(String[] args) {
        imprimirTablero(7,7);;
    }
}