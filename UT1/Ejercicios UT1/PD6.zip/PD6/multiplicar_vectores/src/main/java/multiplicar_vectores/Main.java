package multiplicar_vectores;

public class Main {
    public static void main(String[] args) {
        int[] vector1 = {1, 2, 3};
        int[] vector2 = {4, 5, 6};
        if (vector1.length == vector2.length){
            int resultado = multiplicarVectores(vector1, vector2);
            System.out.println("El resultado de la multiplicacion da: " + resultado);
        } else {
            System.out.println("No se pueden multiplicar porque tienen tamaños distintos");
        }
    }
    public static int multiplicarVectores(int[] vector1, int[] vector2){
        int resultado = 0;
        for (int i = 0; i < vector1.length; i++) {
            resultado += vector1[i] * vector2[i];
        }
        return resultado;

    }
}