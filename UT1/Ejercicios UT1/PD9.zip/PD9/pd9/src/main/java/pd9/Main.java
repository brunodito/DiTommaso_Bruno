package pd9;

public class Main {
    public static void main(String[] args) {
        Ejercicio1 ej1 = new Ejercicio1();
        System.out.println(ej1.calculateFactorial(4));

        Ejercicio2 ej2 = new Ejercicio2();
        System.out.println(ej2.addOddOrEven(100));
    }
}
