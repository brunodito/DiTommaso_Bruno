package pd9;

public class Ejercicio1 {
    public static int calculateFactorial (int number)
    {
    int result = 1;
    if (number < 0){
        throw new IllegalArgumentException ("Los numeros negativos no tienen factorial");
    } else {
        if (number == 0){
            return result;
        } else {
            for ( ; number > 1;  number--)
            {
                result *= number;
            }
            return result;
        }
    }
    }
}
