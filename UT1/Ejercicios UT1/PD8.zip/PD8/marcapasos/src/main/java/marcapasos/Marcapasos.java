package marcapasos;

public class Marcapasos{
    public short presionSanguinea ;
    public short frecuenciaCardiaca ;
    public short nivelDeAzucarEnSangre ;
    public long maxFuerzaExpuesto ;
    public byte minTimeBeetweenHeartbeat ;
    public float bateriaRestante ;
    public char codigoDelFabricante ;

    public Marcapasos (short presionSanguinea, short frecuenciaCardiaca, short nivelDeAzucarEnSangre, long maxFuerzaExpuesto, byte minTimeBeetweenHeartbeat, float bateriaRestante, char codigoDelFabricante) {
            this.presionSanguinea = presionSanguinea;
            this.frecuenciaCardiaca = frecuenciaCardiaca;
            this.nivelDeAzucarEnSangre = nivelDeAzucarEnSangre;
            this.maxFuerzaExpuesto = maxFuerzaExpuesto;
            this.minTimeBeetweenHeartbeat = minTimeBeetweenHeartbeat;
            this.bateriaRestante = bateriaRestante;
            this.codigoDelFabricante = codigoDelFabricante;
        } 
    public static int calcularMemoriaMarcapasos() {
        int sizePresionSanguinea = Short.BYTES;
        int sizeFrecuenciaCardiaca = Short.BYTES;
        int sizeNivelDeAzucarEnSangre = Short.BYTES;
        int sizeMaxFuerzaExpuesto = Long.BYTES;
        int sizeMinTimeBeetweenHeartbeat = Byte.BYTES;
        int sizeBateriaRestante = Float.BYTES;
        int sizeCodigoDelFabricante = Character.BYTES;
        int totalSize = sizePresionSanguinea + sizeFrecuenciaCardiaca + sizeNivelDeAzucarEnSangre + sizeMaxFuerzaExpuesto + sizeMinTimeBeetweenHeartbeat + sizeBateriaRestante + sizeCodigoDelFabricante;
        return totalSize; 
    }
}