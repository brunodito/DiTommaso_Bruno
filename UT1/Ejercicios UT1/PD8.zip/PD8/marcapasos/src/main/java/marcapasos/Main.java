package marcapasos;

public class Main {
    public static void main(String[] args) {
        short A = 10;
        long B = 100;
        byte C = 10;
        Float D = 100.0f;
        char F = 'A';
        Marcapasos javier = new Marcapasos(A,A,A,B,C,D,F);
        javier.calcularMemoriaMarcapasos();
        System.out.println("La memoria consumida por un objeto de la clase Marcapasos es: " + javier.calcularMemoriaMarcapasos() + " bytes");
    }
}