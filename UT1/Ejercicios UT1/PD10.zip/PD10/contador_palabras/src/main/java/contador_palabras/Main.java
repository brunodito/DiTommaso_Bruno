package contador_palabras;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        String [] cadena1 = {"Hola"};
        String [] cadena2 = {"Hola como estan"};
        palabrasComunes(cadena1,cadena2);
    
    public static String[] palabrasComunes (String[] cadena1, String[] cadena2){
        int large;
        int count = 0;
        int count_II = 0;
        if(cadena1.length < cadena2.length){
            large = cadena2.length;
        } else{
            large = cadena1.length;
        }
        String[] duplicate = new String[large];
        for(int i = 0; i < cadena1.length; i++){
            for(int x = 0; x < cadena2.length; x++){
                if(cadena1[i].equals(cadena2[x])){
                    duplicate[i] = cadena1[i];
                }
            }
        }
        for(int i = 0; i < duplicate.length; i++){
            if(duplicate[i] != null){
                count += 1;
            }
        }
        String[] duplicateStrings = new String[contador];
        for(int i = 0; i < duplicate.length; i++){
            if(duplicate[i] != null){
                duplicateStrings[count_II] = duplicate[i];
                count_II += 1;
            }
        }
        return duplicateStrings;
        }
    }
}