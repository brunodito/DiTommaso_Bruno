package alumno;

public class Alumno {

    private String nombre;

    public Alumno () {
        nombre = null;
        }

    public String getNombreAdmiracion() {
        return nombre.concat("!");
    }

    public static void main (String[] args) {
        //Alumno alumno = new Alumno();
        //System.out.println(alumno.getNombreAdmiracion());
        //System.out.println(recorrer("cadena"));
        //System.out.println(getValor());
        //System.out.println(getPrimerCaracter("cadena"));
        //System.out.println(paraAString(2));
    }

public static int recorrer (String cadena) {
    int res = 0;
    for (int i = 1; i <= cadena.length(); i++) {
        if (cadena.charAt(i-1) != ' ') {
            res++;
        }
    }
    return res;
    }

public static int getValor() {
    int vector[] = {6,16,26,36,46,56,66,76};
    int idx = 7;
    return vector[idx];
    }

public static char getPrimerCaracter(String palabra) {
    return (palabra.charAt(0));
    }

public static String paraAString(int a) {
    return Integer.toString(a);
}}

/* 
A- La clase debe llamarse igual que el archivo.java, en mi caso me daba error ya que la clase se llama Alumno y el archivo
se llamaba main.java. Para solucionarlo cambie el nombre de main.java a Alumno.java

B- Al runear el programa me salta el error SystemOutOfBoundsException el cual significa que dentro del for estaba intentando
entrar a un elemento demas en la cadena. Lo solucione agregandole un -1 al indice.

C- Mismo error que en el problema B. Se le pedia que haga un return de vector[8] y vector solo tenia 7 posiciones posibles. 
En caso de querer un return de la ultima posicion, podemos hacer vector[7] ya que sabemos que la ultima posicion es la 7.

D- En este caso el error que me da es NullPointerException. Esta vez lo solucione quitando la lista que no hacia nada y 
modificando el return, ya que antes te devolvia el caracter(1), osea el segundo, y ahora devuelve el (0) osea el primero.

E- En esta parte el programa nos da el error ClassCastException. Se soluciona utilizando la funcion Integer.toString la cual
convierte un int a un string.
 */
