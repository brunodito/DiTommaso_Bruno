package contador;

public class Contador {
    private final int MAX_CONT = 50;
    public int count = 1;
    public int incremento = 1;
    public static void main(String[] args) {
        Contador contador = new Contador();
        //contador.mostrarContador();
        //contador.mostrarContadorDoWhile();
        //contador.mostrarContadorFor();
    }

    public void mostrarContador(){
        while (count <= MAX_CONT) {
            System.out.println(MAX_CONT);
            count += incremento;
        }
    }
    
    public void mostrarContadorDoWhile(){
        do{
            System.out.println(MAX_CONT);
            count += incremento;
        } while (count <= MAX_CONT);
    }

    public void mostrarContadorFor(){
        for (int i = 1 ; count <= MAX_CONT; count += incremento){
            System.out.println(MAX_CONT);
        }
    }

}