package ut1ta2;

public class Ejercicio1 {
    public static int calculateFactorial (int number)
    {
    int result = 1;
    for ( ; number > 1;  number--)
    {
        result *= number;
    }
    return result;
    }
}
