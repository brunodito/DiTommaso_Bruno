package ut1ta2;

public class Ejercicio2 {
    public static long addOddOrEven(long n) {
        long result = 0;
        if (isPrime(n)) {
            long i = 0;
            while (i < n) {
                result += i;
                i += 2;
            }
        } else {
            long i = 1;
            while (i <= n) {
                result += i;
                i += 2;
            }
        }
        return result;
    }
    public static boolean isPrime(long n) {
        boolean prime = true;
        long i = 3;
        while (i <= Math.sqrt(n)) {
            if (n % i == 0) {
            prime = false;
            break;
            }
            i += 2;
        }
        if (( n%2 != 0 && prime && n > 2) || n == 2) {
            return true;
        } else {
            return false;
        }
    }
}
