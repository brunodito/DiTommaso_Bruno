package com.example;

public class Sucursal {
    public String ciudad;

    public Sucursal(String ciudad)
    {
        this.ciudad = ciudad;
    }

    public String getCiudad()
    {
        return this.ciudad;
    }
}
