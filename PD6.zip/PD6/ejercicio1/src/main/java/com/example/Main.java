package com.example;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.LinkedList;

/*
 * Respuesta 1: 107
 * Respuesta 2: Shenzhen
 * Respuesta 3: Ninguna de las anteriores, queda vacía, y no da error porque el método quitarSucursal contempla el caso de borde de que la lista no contenga el elemento a quitar.
 * Respuesta 4: Montreal;_Caracas;_Tulsa;_Mobile;_Vancouver;_
 */

public class Main {
    public static void main(String[] args) {
        Empresa empresa = new Empresa();
        File archivo = new File("ejercicio1/src/sucursales.txt");
        try
        {
            FileReader fr = new FileReader(archivo);
            BufferedReader br = new BufferedReader(fr);
            String lineaActual = br.readLine();
            while(lineaActual != null)
            {
                empresa.agregarSucursal(new Sucursal(lineaActual));
                lineaActual = br.readLine();    
            }

            //Ejercicio 1
            /* 
            System.out.println(empresa.cantSucursales());
            System.out.println(empresa.listarSucursales("\n"));
            */
            
            /*
            //Ejercicio 2
            System.out.println(empresa.quitarSucursal("Chicago"));
            System.out.println(empresa.listarSucursales("\n"));
            */
            
            /*
            //Ejercicio 3
            empresa.quitarSucursal("Shenzhen");
            empresa.quitarSucursal("Tokio");
            System.out.println(empresa.listarSucursales("\n"));
            */
            
            /*
            //Ejercicio 4
            System.out.println(empresa.listarSucursales(";_"));
            */
        }
        catch(Exception e)
        {
            System.out.println("Hubo un error");
        }
    }

    
    
}