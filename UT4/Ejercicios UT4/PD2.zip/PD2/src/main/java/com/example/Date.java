package com.example;

public class Date<T> {
    
}
