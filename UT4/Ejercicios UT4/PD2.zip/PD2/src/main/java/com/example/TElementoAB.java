package com.example;

public class TElementoAB<T> implements IElementoAB{
    private TElementoAB<T> hijoIzquierdo = null;
    private TElementoAB<T> hijoDerecho = null;
    private Comparable etiqueta;
    private T dato;

    public TElementoAB(T dato, Comparable etiqueta){
        this.dato = dato;
        this.etiqueta = etiqueta;
    }

    @Override 
    public Comparable getEtiqueta(){
        return etiqueta;
    }

    @Override
    public TElementoAB<T> getHijoIzq(){
        return hijoIzquierdo;
    }

    @Override
    public TElementoAB<T> getHijoDer(){
        return hijoDerecho;
    }

    @Override
    public void setHijoIzq(TElementoAB elemento){
        this.hijoIzquierdo = elemento;
    }

    @Override
    public void setHijoDer(TElementoAB elemento){
        this.hijoDerecho = elemento;
    }

    @Override
    public TElementoAB<T> buscar(Comparable unaEtiqueta){
        if(this.getEtiqueta().compareTo(unaEtiqueta) == 0){
            return this;
        }
        else if(unaEtiqueta.compareTo(this.getEtiqueta()) <0){
            if(this.getHijoIzq() != null){
                return this.getHijoIzq().buscar(unaEtiqueta);
            }
            else{
                return null;
            }
        }
        else if(unaEtiqueta.compareTo(this.getEtiqueta()) >0){
            if(this.getHijoDer() != null){
                return this.getHijoDer().buscar(unaEtiqueta);
            }
            else{
                return null;
            }
        }
        else{
            return null;
        }
    }

    @Override
    public boolean insertar(TElementoAB elemento){
        if(elemento.getEtiqueta().compareTo(this.getEtiqueta()) < 0){
            if(this.getHijoIzq() == null){
                this.setHijoIzq(elemento);
                return true;
            }
            else{
                return this.getHijoIzq().insertar(elemento);
            }
        }
        else if(elemento.getEtiqueta().compareTo(this.getEtiqueta()) > 0){
            if(this.getHijoDer() == null){
                this.setHijoDer(elemento);
                return true;
            }
            else{
                return this.getHijoDer().insertar(elemento);
            }
        }
        else{
            return false;
        }
    }

    @Override
    public String preOrden(){
        String PreOrden = "";
        PreOrden += this.getEtiqueta() + "-";
        if(this.getHijoIzq() != null){
            PreOrden += getHijoIzq().preOrden();
        }
        if(this.getHijoDer() != null){
            PreOrden += getHijoDer().preOrden();
        }
        return PreOrden;
    }

    @Override
    public String postOrden(){
        String PostOrden = "";
        if(this.getHijoIzq() != null){
            PostOrden += this.getHijoIzq().postOrden();
        }
        if(this.getHijoDer() != null){
            PostOrden += this.getHijoDer().postOrden();
        }
        PostOrden += this.getEtiqueta() + "-";
        return PostOrden;
    }

    @Override
    public String inOrden() {
        String InOrden = "";
        if(this.getHijoIzq() != null){
            InOrden += this.getHijoIzq().inOrden();
        }
        InOrden += this.getEtiqueta() + "-";
        if(this.getHijoDer() != null){
            InOrden += this.getHijoDer().inOrden();
        }
        return InOrden;
    }

    @Override
    public T getDatos(){
        return this.dato;
    }

    @Override
    public TElementoAB eliminar(Comparable unaEtiqueta){
        return null;   
    }
}
