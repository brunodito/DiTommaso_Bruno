package com.example;

public class TArbolBB<T> implements IArbolBB {
    private TElementoAB<T> raiz = null;

    @Override
    public boolean insertar(TElementoAB unElemento) {
        if (this.raiz == null) {
            raiz = unElemento;
            return true;
        } else {
            return raiz.insertar(unElemento);
        }
    }

    @Override
    public TElementoAB<T> buscar(Comparable unaEtiqueta) {
        if (this.raiz == null) {
            return null;
        } else {
            return raiz.buscar(unaEtiqueta);
        }
    }

    @Override
    public String preOrden() {
        if (this.raiz == null) {
            return null;
        } else {
            return raiz.preOrden();
        }
    }

    @Override
    public String postOrden() {
        if (this.raiz == null) {
            return null;
        } else {
            return raiz.postOrden();
        }
    }

    @Override
    public String inOrden() {
        if (this.raiz == null) {
            return null;
        } else {
            return raiz.inOrden();
        }
    }

    @Override
    public void eliminar(Comparable unaEtiqueta){
        
    }
}
