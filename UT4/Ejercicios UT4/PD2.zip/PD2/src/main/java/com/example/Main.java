package com.example;

public class Main {
    public static void main(String[] args) {
        TArbolBB arbolBB = new TArbolBB<>();
        Date dato = new Date<>();
        String[] claves = ManejadorArchivosGenerico.leerArchivo("src\\main\\java\\com\\example\\clavesPrueba.txt");
        for(int i=0; i < claves.length; i++){
            arbolBB.insertar(new TElementoAB(dato, Integer.parseInt(claves[i])));
        }

        String[] Preorden = arbolBB.preOrden().split("-");
        String[] preorden = {"preOrden:", " "};

        String[] Postorden = arbolBB.postOrden().split("-");
        String[] postorden = {"postOrden:", " "};

        String[] Inorden = arbolBB.inOrden().split("-");
        String[] inorden = {"inOrden:", " "};
        
        ManejadorArchivosGenerico.escribirArchivo("src\\main\\java\\com\\example\\recorrido.txt", preorden);
        ManejadorArchivosGenerico.escribirArchivo("src\\main\\java\\com\\example\\recorrido.txt", Preorden);

        ManejadorArchivosGenerico.escribirArchivo("src\\main\\java\\com\\example\\recorrido.txt", postorden);
        ManejadorArchivosGenerico.escribirArchivo("src\\main\\java\\com\\example\\recorrido.txt", Postorden);

        ManejadorArchivosGenerico.escribirArchivo("src\\main\\java\\com\\example\\recorrido.txt", inorden);
        ManejadorArchivosGenerico.escribirArchivo("src\\main\\java\\com\\example\\recorrido.txt", Inorden);

    }
}