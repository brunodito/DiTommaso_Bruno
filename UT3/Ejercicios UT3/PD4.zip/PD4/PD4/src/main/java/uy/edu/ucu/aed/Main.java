package uy.edu.ucu.aed;

/**
 *
 * @author abadie
 */
public class Main {
    
    public static void main(String[] args){
        // TODO: 
        /**
         * Instanciar almacen
         * Agregar: productos y cantidades (altas.txt)
         * Emitir listado de productos y cantidades
         * Emitir valor de stock de todo el almacen
         * Vender: restar stock de productos indicado en ventas.txt
         * Emitir valor de stock de todo el almacen
         **/
        System.err.println("TBD");
    }
    
}
