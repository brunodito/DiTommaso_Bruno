package com.example;

import java.util.LinkedList;

public class Empresa {

    private LinkedList<Sucursal> listaSucursales;

    public Empresa()
    {
        listaSucursales = new LinkedList<Sucursal>();
    }

    public void agregarSucursal(Sucursal sucursal)
    {
        listaSucursales.add(sucursal);
    }

    public String buscarSucursal(Sucursal aBuscar)
    {
        String result = null;
        for (Sucursal sucursal : listaSucursales) {
            if(sucursal == aBuscar)
            {
                result = sucursal.getCiudad();
            }
        }
        return result;
    }

    //Suponemos que no hay elementos repetidos
    public Sucursal quitarSucursal(String datoABuscar)
    {
        Sucursal result = null;
        for (Sucursal sucursal : listaSucursales) {
            if(sucursal.getCiudad().equals(datoABuscar))
            {
                result = sucursal;
            }
        }
        listaSucursales.remove(result);
        return result;
    }

    public String listarSucursales(String separador)
    {
        String listadoSucursales = "";
        for (Sucursal sucursal : listaSucursales) {
            listadoSucursales += sucursal.getCiudad() + separador;
        }
        return listadoSucursales;
    }

    public int cantSucursales()
    {
        return listaSucursales.size();
    }

}
